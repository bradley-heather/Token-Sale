{-# LANGUAGE OverloadedStrings #-}

module Test.Golden.Byron.TxBody
  ( golden_byronTxBody
  ) where

import           Cardano.Prelude
import           Hedgehog (Property)

{- HLINT ignore "Use camelCase" -}

golden_byronTxBody :: Property
golden_byronTxBody = panic "TODO"
